package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.DetalleVentaMongoRepository;
import com.gruporeyes.model.DetalleVentaMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("detalle-venta")
public class DetalleVentaMongoRest {

    @Autowired
    private DetalleVentaMongoRepository detalleVentaMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody DetalleVentaMongo detalleVentaMongo) {
        detalleVentaMongoRepository.save(detalleVentaMongo);
    }

    @GetMapping("/listar")
    public List<DetalleVentaMongo> listar() {
        return detalleVentaMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public DetalleVentaMongo buscarPorId(@PathVariable("id") String id) {
        return detalleVentaMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public DetalleVentaMongo actualizar(@PathVariable String id, @RequestBody DetalleVentaMongo detalleVentaMongo) {
        detalleVentaMongo.setId(id);
        return detalleVentaMongoRepository.save(detalleVentaMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        detalleVentaMongoRepository.deleteById(id);
    }
}
