package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.UsuarioMongoRepository;
import com.gruporeyes.model.UsuarioMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("usuarios")
public class UsuarioMongoRest {

    @Autowired
    private UsuarioMongoRepository usuarioMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody UsuarioMongo usuarioMongo) {
        usuarioMongoRepository.save(usuarioMongo);
    }

    @GetMapping("/listar")
    public List<UsuarioMongo> listar() {
        return usuarioMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public UsuarioMongo buscarPorId(@PathVariable("id") String id) {
        return usuarioMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public UsuarioMongo actualizar(@PathVariable String id, @RequestBody UsuarioMongo usuarioMongo) {
        usuarioMongo.setId(id);
        return usuarioMongoRepository.save(usuarioMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        usuarioMongoRepository.deleteById(id);
    }
}
