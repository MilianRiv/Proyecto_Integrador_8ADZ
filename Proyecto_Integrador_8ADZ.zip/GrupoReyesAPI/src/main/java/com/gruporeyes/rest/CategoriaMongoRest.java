package com.gruporeyes.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.CategoriaMongoRepository;
import com.gruporeyes.model.CategoriaMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("/categorias")
public class CategoriaMongoRest {

    @Autowired
    private CategoriaMongoRepository categoriaMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody CategoriaMongo categoriaMongo) {
        categoriaMongoRepository.save(categoriaMongo);
    }

    @GetMapping("/listar")
    public List<CategoriaMongo> listar() {
        return categoriaMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public CategoriaMongo buscarPorId(@PathVariable("id") String id) {
        return categoriaMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public CategoriaMongo actualizar(@PathVariable String id, @RequestBody CategoriaMongo categoriaMongo) {
        categoriaMongo.setId(id);
        return categoriaMongoRepository.save(categoriaMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        categoriaMongoRepository.deleteById(id);
    }
}
