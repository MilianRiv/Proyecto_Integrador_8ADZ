package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.VentaMongoRepository;
import com.gruporeyes.model.VentaMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("ventas")
public class VentaMongoRest {

    @Autowired
    private VentaMongoRepository ventaMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody VentaMongo ventaMongo) {
        ventaMongoRepository.save(ventaMongo);
    }

    @GetMapping("/listar")
    public List<VentaMongo> listar() {
        return ventaMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public VentaMongo buscarPorId(@PathVariable("id") String id) {
        return ventaMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public VentaMongo actualizar(@PathVariable String id, @RequestBody VentaMongo ventaMongo) {
        ventaMongo.setId(id);
        return ventaMongoRepository.save(ventaMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        ventaMongoRepository.deleteById(id);
    }
}
