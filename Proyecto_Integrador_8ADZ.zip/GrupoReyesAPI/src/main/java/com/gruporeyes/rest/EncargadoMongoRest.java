package com.gruporeyes.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.EncargadoMongoRepository;
import com.gruporeyes.model.EncargadoMongo;

import java.util.List;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("encargados")
public class EncargadoMongoRest {

    @Autowired
    private EncargadoMongoRepository encargadoMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody EncargadoMongo encargadoMongo) {
        encargadoMongoRepository.save(encargadoMongo);
    }

    @GetMapping("/listar")
    public List<EncargadoMongo> listar() {
        return encargadoMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public EncargadoMongo buscarPorId(@PathVariable("id") String id) {
        return encargadoMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public EncargadoMongo actualizar(@PathVariable String id, @RequestBody EncargadoMongo encargadoMongo) {
        encargadoMongo.setId(id);
        return encargadoMongoRepository.save(encargadoMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable String id) {
        encargadoMongoRepository.deleteById(id);
    }
}
