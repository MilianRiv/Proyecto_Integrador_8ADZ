package com.gruporeyes.rest;

import com.gruporeyes.dao.EncargadoMongoRepository;
import com.gruporeyes.model.AuthRequest;
import com.gruporeyes.model.EncargadoMongo;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = {"http://localhost:4200"}) // Permitir solicitudes desde el servidor Angular
public class AuthRest {

    @Autowired
    private EncargadoMongoRepository encargadoMongoRepository;

    // Controlador para iniciar sesión
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AuthRequest authRequest) {
        EncargadoMongo encargado = encargadoMongoRepository.findByCorreoElectronico(authRequest.getCorreoElectronico());
        if (encargado != null && encargado.getContrasena().equals(authRequest.getContrasena())) {
            // Si las credenciales son válidas, puedes devolver algún tipo de identificador o simplemente un mensaje de éxito
            return ResponseEntity.ok().body("Inicio de sesión exitoso");
        } else {
            // Si las credenciales no son válidas, devolver un mensaje de error y un código de estado 401 (No autorizado)
            return ResponseEntity.status(401).body("Credenciales inválidas");
        }
    }

    // Controlador para cerrar sesión
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request) {
        // Invalida la sesión del usuario
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
            return ResponseEntity.ok().body("Sesión cerrada exitosamente");
        } else {
            // Si no hay una sesión activa, devuelve un mensaje de error
            return ResponseEntity.status(401).body("No se encontró una sesión activa para cerrar");
        }
    }
}
