package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.ProductoMongoRepository;
import com.gruporeyes.model.ProductoMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("productos")
public class ProductoMongoRest {

    @Autowired
    private ProductoMongoRepository productoMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody ProductoMongo productoMongo) {
        productoMongoRepository.save(productoMongo);
    }

    @GetMapping("/listar")
    public List<ProductoMongo> listar() {
        return productoMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public ProductoMongo buscarPorId(@PathVariable("id") String id) {
        return productoMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public ProductoMongo actualizar(@PathVariable String id, @RequestBody ProductoMongo productoMongo) {
        productoMongo.setId(id);
        return productoMongoRepository.save(productoMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        productoMongoRepository.deleteById(id);
    }
}
