package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.ProveedorMongoRepository;
import com.gruporeyes.model.ProveedorMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("proveedores")
public class ProveedorMongoRest {

    @Autowired
    private ProveedorMongoRepository proveedorMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody ProveedorMongo proveedorMongo) {
        proveedorMongoRepository.save(proveedorMongo);
    }

    @GetMapping("/listar")
    public List<ProveedorMongo> listar() {
        return proveedorMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public ProveedorMongo buscarPorId(@PathVariable("id") String id) {
        return proveedorMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public ProveedorMongo actualizar(@PathVariable String id, @RequestBody ProveedorMongo proveedorMongo) {
        proveedorMongo.setId(id);
        return proveedorMongoRepository.save(proveedorMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        proveedorMongoRepository.deleteById(id);
    }
}
