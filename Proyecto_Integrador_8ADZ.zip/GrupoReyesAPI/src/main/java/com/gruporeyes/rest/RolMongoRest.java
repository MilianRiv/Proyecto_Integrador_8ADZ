package com.gruporeyes.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.gruporeyes.dao.RolMongoRepository;
import com.gruporeyes.model.RolMongo;
@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("roles")
public class RolMongoRest {

    @Autowired
    private RolMongoRepository rolMongoRepository;

    @PostMapping("/crear")
    public void crear(@RequestBody RolMongo rolMongo) {
        rolMongoRepository.save(rolMongo);
    }

    @GetMapping("/listar")
    public List<RolMongo> listar() {
        return rolMongoRepository.findAll();
    }

    @GetMapping("/buscar/{id}")
    public RolMongo buscarPorId(@PathVariable("id") String id) {
        return rolMongoRepository.findById(id).orElse(null);
    }

    @PutMapping("/actualizar/{id}")
    public RolMongo actualizar(@PathVariable String id, @RequestBody RolMongo rolMongo) {
        rolMongo.setId(id);
        return rolMongoRepository.save(rolMongo);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminar(@PathVariable("id") String id) {
        rolMongoRepository.deleteById(id);
    }
}
