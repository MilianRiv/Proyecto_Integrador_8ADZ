package com.gruporeyes.model;

public class AuthRequest {
    private String correoElectronico;
    private String contrasena;

    // Constructor, getters y setters
    public AuthRequest() {
    }

    public AuthRequest(String correoElectronico, String contrasena) {
        this.correoElectronico = correoElectronico;
        this.contrasena = contrasena;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}
