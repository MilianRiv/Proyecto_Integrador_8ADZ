package com.gruporeyes.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Document(collection = "categorias")
public class CategoriaMongo {

    @Id
    private String id;

    @Field("nombre")
    private String nombre;

    @Field("productos")
    private List<ProductoMongo> productos;

    public CategoriaMongo() {
    }

    public CategoriaMongo(String nombre, List<ProductoMongo> productos) {
        this.nombre = nombre;
        this.productos = productos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<ProductoMongo> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoMongo> productos) {
        this.productos = productos;
    }
}
