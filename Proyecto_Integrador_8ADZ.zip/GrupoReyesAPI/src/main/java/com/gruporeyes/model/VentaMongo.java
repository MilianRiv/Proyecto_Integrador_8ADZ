package com.gruporeyes.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.sql.Timestamp;

@Document(collection = "ventas")
public class VentaMongo {

    @Id
    private String id;

    private Timestamp fecha;

    private Float totalVenta;

    private EncargadoMongo encargado;

    public VentaMongo() {
    }

    public VentaMongo(Timestamp fecha, Float totalVenta, EncargadoMongo encargado) {
        this.fecha = fecha;
        this.totalVenta = totalVenta;
        this.encargado = encargado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public Float getTotalVenta() {
        return totalVenta;
    }

    public void setTotalVenta(Float totalVenta) {
        this.totalVenta = totalVenta;
    }

    public EncargadoMongo getEncargado() {
        return encargado;
    }

    public void setEncargado(EncargadoMongo encargado) {
        this.encargado = encargado;
    }
}
