package com.gruporeyes.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "usuarios")
public class UsuarioMongo {

    @Id
    private String id;

    private String nombre;
    private String correoElectronico;
    private String contrasena;
    private String imagenUsuarios;

    // Constructor, getters y setters

    public UsuarioMongo() {}

    public UsuarioMongo(String nombre, String correoElectronico, String contrasena, String imagenUsuarios) {
        this.nombre = nombre;
        this.correoElectronico = correoElectronico;
        this.contrasena = contrasena;
        this.imagenUsuarios = imagenUsuarios;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getImagenUsuarios() {
        return imagenUsuarios;
    }

    public void setImagenUsuarios(String imagenUsuarios) {
        this.imagenUsuarios = imagenUsuarios;
    }

    @Override
    public String toString() {
        return "UsuarioMongo{" +
                "id='" + id + '\'' +
                ", nombre='" + nombre + '\'' +
                ", correoElectronico='" + correoElectronico + '\'' +
                ", contrasena='" + contrasena + '\'' +
                ", imagenUsuarios='" + imagenUsuarios + '\'' +
                '}';
    }
}
