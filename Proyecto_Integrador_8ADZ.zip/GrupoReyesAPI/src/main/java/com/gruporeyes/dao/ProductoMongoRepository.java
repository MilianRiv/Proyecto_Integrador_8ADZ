package com.gruporeyes.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.gruporeyes.model.ProductoMongo;

@Repository
public interface ProductoMongoRepository extends MongoRepository<ProductoMongo, String> {
}
