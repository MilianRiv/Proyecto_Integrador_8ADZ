package com.gruporeyes.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.gruporeyes.model.EncargadoMongo;

@Repository
public interface EncargadoMongoRepository extends MongoRepository<EncargadoMongo, String> {
	EncargadoMongo findByCorreoElectronico(String correoElectronico);
    // No es necesario agregar ningún método aquí, heredamos todos los métodos de MongoRepository
}