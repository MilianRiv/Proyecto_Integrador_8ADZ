package com.gruporeyes.dao;

import com.gruporeyes.model.VentaMongo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VentaMongoRepository extends MongoRepository<VentaMongo, String> {
}
